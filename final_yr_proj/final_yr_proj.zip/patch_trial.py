from scipy.io import loadmat
import numpy as np
import scipy.io
import numpy as np
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
import keras
from keras.wrappers.scikit_learn import KerasClassifier
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten,Activation
from keras.layers import Conv2D, MaxPooling2D, AveragePooling2D
from keras.optimizers import SGD
import pandas as pd
from keras import backend as K
from keras.utils import to_categorical
import tensorflow as tf


def get_data():
    data_dic = {}
    data = loadmat("Indian_pines.mat")['indian_pines']
    target_mat = scipy.io.loadmat("Indian_pines_gt.mat")['indian_pines_gt']
    target_mat = np.array(target_mat)
    labels = []
    for i in range(145):
    	for j in range(145):
    		labels.append(target_mat[i , j])
    labels = np.array(labels)
    #print max(labels), min(labels)
    #labels = target_mat #keras.utils.to_categorical(labels)
    #labels = np.reshape(target_mat, (21025,1))
    #print labels.shape
    d = data
    #d1 = np.pad(d, ((2,2), (2,2), (0,0)), mode='constant', constant_values=0)
    #print d1.shape, d1
    d= np.array(d)
    d = d.astype(float)
    d -= np.min(d)
    d /= np.max(d)

    y = []
    for i in range(d.shape[2]):
         dd = np.pad(d[0:d.shape[0],0:d.shape[1],i], [(2,2),(2,2)], mode='constant')
         y.append(dd)
    y = np.array(y)

    #print y[0]
    #d_p1 = np.dstack((y))
    #print  y.shape
    y1 = []
    for i in range(2, y.shape[1]-2):
        for j in range(2, y.shape[2]-2):
            y1.append(y[:, i-2:i+3, j-2:j+3])
    yy = np.array(y1)
    y1 = np.array(y1)
    #print y1.shape,y1[0,:,2,2]
    y1 = np.transpose(y1, (0,2,3,1))
    #print y1.shape, yy[0,:,2,2] == y1[0,2,2,:]

    data = y1
    #print data.shape
    data_dic['data'] = data
    data_dic['labels'] = labels
    #print labels.shape
    #y_train = keras.utils.to_categorical(y_train)
    return data_dic
k = get_data()
#print k
#print k
def final_data(k):
    fin_data_dic = {}
    top_classes = list(pd.Series(k['labels']).value_counts().index[0:8])
    #print "TopClasses****************",top_classes
    k_df = pd.DataFrame(k['labels'], columns=['a'])
    #print y_df.values, y_df.values.shape
    k_df_loc = k_df.loc[k_df['a'].isin(top_classes),:]
    #y_df_loc1 = y_df.loc[y_df['a'],:]
    top_8_index = k_df_loc.index


    y_new = []
    X_new = []
    for i in top_8_index:
        X_new.append(k['data'][i])
        y_new.append(k['labels'][i])

    X_new = np.array(X_new)
    #y_new = np.array(y_new)
    #y_new = np.reshape(y_new, (y_new.shape[0],1))
    #print X_new.shape, len(y_new), min(y_new), max(y_new)

    for i in range(len(y_new)):
    	if y_new[i] == 0:
    		y_new[i]= int(0)
    	elif y_new[i] == 11:
    		y_new[i]= int(1)
    	elif y_new[i] == 2:
    		y_new[i] = int(2)
    	elif y_new[i] == 14:
    		y_new[i] = int(3)
    	elif y_new[i] == 10:

    		y_new[i] = int(4)
    	elif y_new[i] == 3:
    		y_new[i] = int(5)
    	elif y_new[i] == 6:
    		y_new[i]= int(6)
    	elif y_new[i] == 12:
    		y_new[i] = int(7)
    #def one_hot_enc(l):
    y_new = np.array(y_new)
    y_new = to_categorical(y_new)
    x_train, y_train = X_new[0:int(0.75*X_new.shape[0]),:,:,:], y_new[0:int(0.75*y_new.shape[0]),:]
    #x_val, y_val = X_new[int(0.6*X_new.shape[0]):int(0.8*X_new.shape[0]),:,:,:], y_new[int(0.6*y_new.shape[0]):int(0.8*y_new.shape[0]),:]
    x_test, y_test = X_new[int(0.75*X_new.shape[0]):int(1.0*X_new.shape[0]),:,:,:], y_new[int(0.75*y_new.shape[0]):int(1.0*y_new.shape[0]),:]
    dic_train, dic_val, dic_test = {}, {}, {}

    dic_train['data'], dic_train['labels'] = x_train, y_train
    #dic_val['data'], dic_val['labels'] = x_val, y_val
    dic_test['data'], dic_test['labels'] = x_test, y_test
    fin_data_dic['train'] = dic_train
    #fin_data_dic['val'] = dic_val
    fin_data_dic['test'] = dic_test
    #print X_new.shape, y_new.shape
    return fin_data_dic#, min(y_new), max(y_new)
kk = final_data(k)
print kk.keys()
def final_data_aug(kk):
    dic_train_aug, dic_test_aug = {}, {}
    fin_data_dic_aug = {}
    x_train, x_test = kk['train']['data'], kk['test']['data']
    y_train, y_test = kk['train']['labels'], kk['test']['labels']
    print x_train.shape
    #x_train, x_test = list(x_train), list(x_test)
    #y_train, y_test = list(y_train), list(y_test)

    x_train_aug, x_test_aug, y_train_aug, y_test_aug = [], [], [], []

    for i in x_train:
        #print i.shape
        x_train_aug.append(i)
        x_train_aug.append(np.flipud(i))
        x_train_aug.append(np.fliplr(i))
        x_train_aug.append(np.transpose(i, (1,0,2)))
    tot_len = len(x_train_aug)
    x_train_aug = np.array(x_train_aug)
    x_train_aug = np.reshape(x_train_aug, (tot_len,5,5,220))
    print x_train_aug[2].shape

    for i1 in x_test:
        #print i.shape
        x_test_aug.append(i1)
        x_test_aug.append(np.flipud(i1))
        x_test_aug.append(np.fliplr(i1))
        x_test_aug.append(np.transpose(i1, (1,0,2)))
    tot_len = len(x_test_aug)
    x_test_aug = np.array(x_test_aug)
    #x_train_aug = np.reshape(x_train_aug, (tot_len,5,5,220))
    print x_test_aug.shape


    for i2 in y_train:
        #print i.shape
        y_train_aug.append(i2)
        y_train_aug.append(i2)
        y_train_aug.append(i2)
        y_train_aug.append(i2)
    #tot_len = len(x_train_aug)
    y_train_aug = np.array(y_train_aug)
    #x_train_aug = np.reshape(x_train_aug, (tot_len,5,5,220))
    print y_train_aug.shape

    for i3 in y_test:
        #print i.shape
        y_test_aug.append(i3)
        y_test_aug.append(i3)
        y_test_aug.append(i3)
        y_test_aug.append(i3)
    #tot_len = len(x_train_aug)
    y_test_aug = np.array(y_test_aug)
    #x_test_aug = np.reshape(x_test_aug, (tot_len,5,5,220))
    print y_test_aug.shape

    dic_train_aug['data'], dic_test_aug['data'], dic_train_aug['labels'], dic_test_aug['labels'] = x_train_aug, x_test_aug, y_train_aug, y_test_aug

    fin_data_dic_aug['train'] = dic_train_aug
    fin_data_dic_aug['test'] = dic_test_aug
    return fin_data_dic_aug



'''for i in top_8_index:

	X_new.append(k['data'][i])
	y_new.append(k['labels'][i])
    print X_new, y_new, i
print  len(y_new),max(y_new),min(y_new)
'''


#print y1[0]




















'''def extract_patches(imgs, landmarks, patch_shape):
    """ Extracts patches from an image.
    Args:
        imgs: a numpy array of dimensions [batch_size, width, height, channels]
        landmarks: a numpy array of dimensions [num_patches, 2]
        patch_shape: (width, height)
    Returns:
        a numpy array [num_patches, width, height, channels]
    """

    patch_shape = np.array(patch_shape)
    patch_half_shape = np.require(np.round(patch_shape / 2), dtype=int)
    start = -patch_half_shape
    end = patch_half_shape
    sampling_grid = np.mgrid[start[0]:end[0], start[1]:end[1]]
    sampling_grid = sampling_grid.swapaxes(0, 2).swapaxes(0, 1)

    list_patches = []

    for i in range(imgs.shape[0]):

        img, ldm = imgs[i], landmarks[i]
        img = img.transpose(2, 0, 1)

        max_x = img.shape[-2] - 1
        max_y = img.shape[-1] - 1

        patch_grid = sampling_grid[None, :, :, :] + ldm[:, None, None, :]


        X = patch_grid[:, :, :, 0].clip(0, max_x)
        Y = patch_grid[:, :, :, 1].clip(0, max_y)

        patches = img[:, Y, X].transpose(1, 3, 2, 0)
        list_patches.append(patches)

        # # Plot for debugging
        # plt.figure()
        # plt.imshow(img[0, :, :], cmap="gray")
        # plt.scatter(ldm[:, 0], ldm[:, 1])

        # gs = gridspec.GridSpec(5, 1)
        # fig = plt.figure(figsize=(15, 15))
        # for i in range(5):
        #     ax = plt.subplot(gs[i])
        #     ax.imshow(patches[i, :, :, 0], cmap="gray")
        # gs.tight_layout(fig)
        # plt.show()

    return np.array(list_patches).astype(np.float32)
d = scipy.io.loadmat("Indian_pines.mat")
d = scipy.io.loadmat("Indian_pines.mat")['indian_pines']
d = np.array(d)
d = np.reshape(d,(1,145,145,220))
lmds = np.array([21025,2])
ps = np.array([5,5])
kk = extract_patches(d,lmds,ps)
print kk
'''
'''
atr_new, ate_new, data_arr_tr, data_arr_te = [], [], [], []
iii = loadmat("Test_5_2.mat")
#print iii
for i in range(8):
    atr_new.append("Train_5"+"_"+str(i+1)+".mat")
for ii in range(6):
    ate_new.append("Test_5"+"_"+str(ii+1)+".mat")
print atr_new, ate_new
for i1 in atr_new:
    print i1
    dat = loadmat(i1)
    data_arr_tr.append(dat)
for i2 in ate_new:
    dat1 = loadmat(i2)
    data_arr_te.append(dat1)
k = data_arr_te[0]['test_patch'].reshape(400,5,5,220)
kk = data_arr_tr[0]['train_patch'].reshape(400,5,5,220)
print k.shape, kk.shape#data_arr_te[0]['test_patch'].shape, data_arr_tr[0]['train_patch'].shape
'''
